module PBII2023GavagninLucasDaniel {
	requires junit;
}