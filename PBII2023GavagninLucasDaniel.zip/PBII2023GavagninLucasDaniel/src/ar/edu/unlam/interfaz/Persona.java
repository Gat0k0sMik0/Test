package ar.edu.unlam.interfaz;
import java.util.HashSet;
import java.util.Set;

public abstract class Persona {
	protected String nombre;
	protected Integer identificador;
	protected Set<Transaccion> transaciones;
	protected Set<MedioPago> tarjetas;
	protected Set<Transferible> cuentas;
	protected CuentaVirtual cuentaPrincipal;

	public Persona(String nombre, Integer identficador) {
		super();
		this.nombre = nombre;
		this.identificador = identficador;
		this.transaciones = new HashSet<>();
		this.tarjetas = new HashSet<>();
		this.cuentas = new HashSet<>();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Set<Transaccion> getTransaciones() {
		return transaciones;
	}

	public void setTransaciones(Set<Transaccion> transaciones) {
		this.transaciones = transaciones;
	}
	
	public void agregarTransaccion(Transaccion transaccion) {
		this.transaciones.add(transaccion);
	}
	
	public void agregarTarjeta(MedioPago medio) {
		this.tarjetas.add(medio);
	}
	
	public boolean validarDebito(MedioPago tarjeta) {
		if(tarjeta instanceof TarjetaDebito) {
			
		}
		return false;
	}

	public Integer getIdentificador() {
		return identificador;
	}

	public void setIdentificador(Integer identificador) {
		this.identificador = identificador;
	}

	public Set<MedioPago> getTarjetas() {
		return tarjetas;
	}

	public void setTarjetas(Set<MedioPago> tarjetas) {
		this.tarjetas = tarjetas;
	}

	public Set<Transferible> getCuentas() {
		return cuentas;
	}

	public void setCuentas(Set<Transferible> cuentas) {
		this.cuentas = cuentas;
	}
	
	public void agregarTarjetaPrincipal(CuentaVirtual medio) {
		this.cuentaPrincipal = medio;
	}

	public CuentaVirtual getTarjetaPrincipal() {
		return cuentaPrincipal;
	}

	public void setTarjetaPrincipal(CuentaVirtual tarjetaPrincipal) {
		this.cuentaPrincipal = tarjetaPrincipal;
	}
	
	
}
