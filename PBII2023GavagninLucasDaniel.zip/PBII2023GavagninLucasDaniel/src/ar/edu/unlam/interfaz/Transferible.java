package ar.edu.unlam.interfaz;

public interface Transferible {
	Double getSaldo();
	void depositar(Double importe);
	Boolean extraer(Double importe);
}
