package ar.edu.unlam.interfaz;

public class Juridica extends Persona {

	public Juridica(String nombre, Integer cuit) {
		super(nombre, cuit);
	}

	

	
}
