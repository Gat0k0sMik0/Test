package ar.edu.unlam.interfaz;
import java.util.*;
public class OrdenarPersonasPorIdentificador implements Comparator<Persona>{

	@Override
	public int compare(Persona o1, Persona o2) {
		return o2.getIdentificador().compareTo(o1.getIdentificador());
	}

}
