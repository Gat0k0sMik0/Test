package ar.edu.unlam.interfaz;

public class Fisica extends Persona {

	public Fisica(String nombre, Integer cuil) {
		super(nombre, cuil);
		
	}
	
}
