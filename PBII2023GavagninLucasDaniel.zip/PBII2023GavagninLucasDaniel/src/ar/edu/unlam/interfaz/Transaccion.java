package ar.edu.unlam.interfaz;

public class Transaccion implements Pagadora {
	protected Integer importe;
	protected Integer codigo;
	
	public Transaccion(Integer importe, Integer codigo) {
		this.importe = importe;
		this.codigo = codigo;
	}
	
	public Integer getImporte() {
		return importe;
	}
	
	public void setImporte(Integer importe) {
		this.importe = importe;
	}
	
	public Integer getCodigo() {
		return codigo;
	}
	
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	@Override
	public Boolean pagar(Persona destinatario, Double importe) {
		destinatario.getTarjetaPrincipal().depositar(importe);
		return null;
	}
}
