package ar.edu.unlam.interfaz;

public class CuentaBancaria  implements Transferible {
	private Integer cbu;
	private String nombre;
	private Double saldo;
	
	public CuentaBancaria(Integer cbu, String nombre) {
		this.nombre = nombre;
		this.cbu = cbu;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Double getDineroDisponible() {
		return saldo;
	}

	public void setDineroDisponible(Double dineroDisponible) {
		this.saldo = dineroDisponible;
	}

	public Integer getCbu() {
		return cbu;
	}

	public void setCbu(Integer cbu) {
		this.cbu = cbu;
	}
	
	@Override
	public void depositar(Double importe) {
		this.saldo += importe;
	}
	
	@Override
	public Boolean extraer(Double importe) {
		this.saldo -= importe;
		return true;
	}
	
	@Override
	public Double getSaldo() {
		return saldo;
	}

	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}

	
}
