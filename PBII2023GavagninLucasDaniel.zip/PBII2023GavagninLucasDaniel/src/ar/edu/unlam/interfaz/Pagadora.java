package ar.edu.unlam.interfaz;

public interface Pagadora {
	Boolean pagar(Persona dstinatario, Double importe);
}
