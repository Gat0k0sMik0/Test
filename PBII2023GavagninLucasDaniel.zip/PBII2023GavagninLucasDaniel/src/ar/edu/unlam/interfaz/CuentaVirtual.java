package ar.edu.unlam.interfaz;

public class CuentaVirtual implements Transferible {
	private Integer cvu;
	private String nombre;
	private Double saldo;
	
	public CuentaVirtual(Integer cvu, String nombre) {
		this.nombre = nombre;
		this.cvu = cvu;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Integer getCvu() {
		return cvu;
	}

	public void setCvu(Integer cvu) {
		this.cvu = cvu;
	}
	
	public void ingresarDinero(Integer importe) {
		this.saldo += importe;
	}
	
	public void retirarDinero(Integer importe) {
		this.saldo -= importe;
	}

	@Override
	public void depositar(Double importe) {
		this.saldo += importe;
	}
	
	@Override
	public Boolean extraer(Double importe) {
		this.saldo -= importe;
		return true;
	}
	
	@Override
	public Double getSaldo() {
		return saldo;
	}

	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}
	
}