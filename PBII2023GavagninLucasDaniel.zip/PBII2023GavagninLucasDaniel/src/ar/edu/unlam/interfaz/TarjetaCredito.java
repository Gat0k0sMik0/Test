package ar.edu.unlam.interfaz;

public class TarjetaCredito extends MedioPago {
	private Integer compras;
	private Integer comprasHechas;
	private Integer numero;
	
	public TarjetaCredito(String nombre, Integer saldo, Integer numero) {
		super(nombre, saldo);
		this.compras = 0;
		this.comprasHechas = 0;
		this.numero = numero;
	}
	
	public boolean validarCompras() {
		if(this.compras < this.comprasHechas) {
			return true;
		}
		return false;
	}

	public Integer getCompras() {
		return compras;
	}

	public void setCompras(Integer compras) {
		this.compras = compras;
	}

	public Integer getComprasHechas() {
		return comprasHechas;
	}

	public void setComprasHechas(Integer comprasHechas) {
		this.comprasHechas = comprasHechas;
	}

	public Integer getNumero() {
		return numero;
	}

	public void setNumero(Integer numero) {
		this.numero = numero;
	}
	
	
	
}
