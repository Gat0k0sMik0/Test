package ar.edu.unlam.interfaz;

import java.util.*;

public class BilleteraDePago {
	private Set<Persona> personas;
	private Set<Transaccion> transacciones;
	private String nombre;
	
	public BilleteraDePago(String nombre) {
		super();
		this.nombre = nombre;
		this.personas = new TreeSet<>(new OrdenarPersonasPorIdentificador());
		this.transacciones = new HashSet<>();
	}
	
	public void agregarPersona(Persona persona) {
		this.personas.add(persona);
	}
	
	public void agregarTransaccion(Transaccion transaccion) {
		this.transacciones.add(transaccion);
	}
	
	public Set<MedioPago> verMedios(Persona persona) {
		return persona.getTarjetas();
	}
	
	public Map<Persona, Set<MedioPago>> verMediosDePersonas() {
		Map<Persona, Set<MedioPago>> vendedorYMedios = new HashMap<>();
		for(Persona persona : personas) {
			if(!vendedorYMedios.containsKey(persona)) {
				Set<MedioPago> mediosPersona = new HashSet<>();
				mediosPersona.addAll(persona.getTarjetas());
				vendedorYMedios.put(persona, mediosPersona);
			}
		}
		return vendedorYMedios;
	}
	
	public void agregarMedios(Persona persona, MedioPago tarjeta) {
		persona.agregarTarjeta(tarjeta);
	}
	
	public boolean transferir(Persona persona, Persona destinatario) {
		//if(persona.getTarjetaPrincipal().pagar(destinatario));
		return false;
		
	}

	public Set<Persona> getPersonas() {
		return personas;
	}

	public void setPersonas(Set<Persona> personas) {
		this.personas = personas;
	}

	public Set<Transaccion> getTransacciones() {
		return transacciones;
	}

	public void setTransacciones(Set<Transaccion> transacciones) {
		this.transacciones = transacciones;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
}
