package ar.edu.unlam.interfaz;

public abstract class MedioPago {
	protected String nombre;
	protected Integer saldo; 
	
	public MedioPago(String nombre, Integer saldo) {
		this.nombre = nombre;	
		this.saldo = saldo;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	
}
