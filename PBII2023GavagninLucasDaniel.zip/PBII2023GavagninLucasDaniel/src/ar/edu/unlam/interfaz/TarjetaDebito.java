package ar.edu.unlam.interfaz;

public class TarjetaDebito extends MedioPago implements Pagadora {
	private Integer numero;
	
	public TarjetaDebito(String nombre, Integer numero, Integer saldo) {
		super(nombre, saldo);
		this.numero = numero;
	}
	
	public boolean validarSaldo(Double importe) {
		if(this.saldo < importe) {
			return false;
		}
		return true;
	}

	@Override
	public Boolean pagar(Persona destinatario, Double importe) {
		if(!validarSaldo(importe)) {
			destinatario.getTarjetaPrincipal().depositar(importe);
		}
		return null;
	}

	public Integer getNumero() {
		return numero;
	}

	public void setNumero(Integer numero) {
		this.numero = numero;
	}
	
}
