package ar.edu.unlam.Test;

import static org.junit.Assert.*;

import java.util.*;

import ar.edu.unlam.interfaz.*;

public class Test {

	@org.junit.Test
	public void queSePuedanAlmacenarLosDistintosTiposDeTransacciones() {
		Transaccion t1 = new Transaccion(12300, 1);
		Transaccion t2 = new Transaccion(2344, 2);
		Transaccion t3 = new Transaccion(9000, 3);
		Transaccion t4 = new Transaccion(7886, 4);
		BilleteraDePago billetera = new BilleteraDePago("Bille");
		Set<Transaccion> billeEsperada = new HashSet<>();
		billeEsperada.add(t1);
		billeEsperada.add(t2);
		billeEsperada.add(t3);
		billeEsperada.add(t4);

		
		billetera.agregarTransaccion(t1);
		billetera.agregarTransaccion(t2);
		billetera.agregarTransaccion(t3);
		billetera.agregarTransaccion(t4);

		assertEquals(billeEsperada, billetera.getTransacciones());
	}
	
	@org.junit.Test
	public void queSePuedanAlmacenarLosDistintosTiposDePersonas() {
		Persona p1 = new Fisica("Pablo", 463649287);
		Persona p2 = new Fisica("Pablo", 563649287);
		Persona p3 = new Fisica("Pablo", 306365487);
		Persona p4 = new Fisica("Pablo", 463649532);
		BilleteraDePago billetera = new BilleteraDePago("Mordin");
		Set<Persona> personasEsperadas = new TreeSet<>(new OrdenarPersonasPorIdentificador());
		personasEsperadas.add(p1);
		personasEsperadas.add(p2);
		personasEsperadas.add(p3);
		personasEsperadas.add(p4);
		
		billetera.agregarPersona(p1);
		billetera.agregarPersona(p2);
		billetera.agregarPersona(p3);
		billetera.agregarPersona(p4);
		
		
		assertEquals(personasEsperadas, billetera.getPersonas());
	}
	
	@org.junit.Test
	public void queSePuedanAsociarACadaPeronaSusMedios() {
		Persona p1 = new Fisica("Pablo", 463649287);
		Persona p2 = new Fisica("Pablo", 563649287);
		Persona p3 = new Fisica("Pablo", 306365487);
		Persona p4 = new Fisica("Pablo", 463649532);
		Transferible cuenta = new CuentaVirtual(null, null); 
		BilleteraDePago billetera = new BilleteraDePago("Mordin");
		MedioPago medio1 = new TarjetaDebito("VISA", 259865642, 976624);
		MedioPago medio2 = new TarjetaCredito("MASTERCARD", 902072432, 52665);
		Set<MedioPago> mediosP1 = new HashSet<>();
		mediosP1.add(medio1);
		mediosP1.add(medio2);
		Set<MedioPago> mediosP2 = new HashSet<>();
		mediosP2.add(medio1);
		mediosP2.add(medio2);
		Set<MedioPago> mediosP3 = new HashSet<>();
		mediosP3.add(medio1);
		mediosP3.add(medio2);
		Set<MedioPago> mediosP4 = new HashSet<>();
		mediosP4.add(medio1);
		mediosP4.add(medio2);
		Map<Persona, Set<MedioPago>> mediosGeneral = new HashMap<>();
		mediosGeneral.put(p1, mediosP1);
		mediosGeneral.put(p2, mediosP2);
		mediosGeneral.put(p3, mediosP3);
		mediosGeneral.put(p4, mediosP4);
		
		billetera.agregarPersona(p1);
		billetera.agregarPersona(p2);
		billetera.agregarPersona(p3);
		billetera.agregarPersona(p4);
		billetera.agregarMedios(p1, medio1);
		billetera.agregarMedios(p1, medio2);
		billetera.agregarMedios(p2, medio1);
		billetera.agregarMedios(p2, medio2);
		billetera.agregarMedios(p3, medio1);
		billetera.agregarMedios(p3, medio2);
		billetera.agregarMedios(p4, medio1);
		billetera.agregarMedios(p4, medio2);
		
		assertEquals(mediosP1, billetera.verMedios(p1));
		assertEquals(mediosGeneral, billetera.verMediosDePersonas());
	}
	
	/*public void queSePuedanRealizarCompras() {
		Persona p1 = new Fisica("Pablo", 463649287);
		Persona p2 = new Fisica("Pablo", 563649287);
		Persona p3 = new Fisica("Pablo", 306365487);
		Persona p4 = new Fisica("Pablo", 463649532);
		BilleteraDePago billetera = new BilleteraDePago("Mordin");
		Set<Persona> personasEsperadas = new TreeSet<>(new OrdenarPersonasPorIdentificador());
		personasEsperadas.add(p1);
		personasEsperadas.add(p2);
		personasEsperadas.add(p3);
		personasEsperadas.add(p4);
		
		billetera.agregarPersona(p1);
		billetera.agregarPersona(p2);
		billetera.agregarPersona(p3);
		billetera.agregarPersona(p4);
		
		
		assertEquals(personasEsperadas, billetera.getPersonas());
	}*/
	

}
